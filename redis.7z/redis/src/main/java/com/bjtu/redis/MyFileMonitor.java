package com.bjtu.redis;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import org.apache.commons.io.filefilter.FileFilterUtils;
import org.apache.commons.io.monitor.FileAlterationListener;
import org.apache.commons.io.monitor.FileAlterationMonitor;
import org.apache.commons.io.monitor.FileAlterationObserver;

import java.io.File;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import static com.bjtu.redis.JsonUtil.readJsonFile;



public class MyFileMonitor {
    public static void run() throws Exception{
        File directory = new File("src/main/resources");//需要扫描的文件夹路径
        long interval = TimeUnit.SECONDS.toMillis(1);
        // 创建一个文件观察器用于处理文件的格式，比如：扫描F盘下面的scandata文件夹中，新建以后缀为.success结尾的文件
        FileAlterationObserver observer = new FileAlterationObserver(directory, FileFilterUtils.and(
                FileFilterUtils.fileFileFilter(),FileFilterUtils.suffixFileFilter(".json")));
        observer.addListener(new MyFileListener());
        FileAlterationMonitor monitor = new FileAlterationMonitor(interval,observer);
        monitor.start();
    }
}
final class MyFileListener implements FileAlterationListener{
    @Override
    public void onStart(FileAlterationObserver fileAlterationObserver) {
//        System.out.println("monitor start scan files..");
    }


    @Override
    public void onDirectoryCreate(File file) {
        System.out.println(file.getName()+" director created.");
    }


    @Override
    public void onDirectoryChange(File file) {
        System.out.println(file.getName()+" director changed.");
    }


    @Override
    public void onDirectoryDelete(File file) {
        System.out.println(file.getName()+" director deleted.");
    }


    @Override
    public void onFileCreate(File file) {
        String name = file.getName();
        String substring = name.substring(0, 8);
        System.out.println("时间为："+substring);
        System.out.println(name +" created.");
    }


    @Override
    public void onFileChange(File file) {
//        System.out.println(file.getName()+" changed.");

        if(file.getName().equals("object.json")){
            JSONObject jsonObj = JSON.parseObject(readJsonFile(MyConstant.objectPath));

            RedisHWMain.jedis.set("fzr_object", jsonObj.toString());
        }else if(file.getName().equals("ObjectFreq.json")){
            JSONObject jsonObj = JSON.parseObject(readJsonFile(MyConstant.objectPath));

            Map m1 = (Map)JSON.parse(JsonUtil.readJsonFile(MyConstant.freqPath));
            RedisHWMain.jedis.hmset("fzr_freq",m1);
        }

    }


    @Override
    public void onFileDelete(File file) {
        System.out.println(file.getName()+" deleted.");
    }


    @Override
    public void onStop(FileAlterationObserver fileAlterationObserver) {
//        System.out.println("monitor stop scanning..");
    }
}