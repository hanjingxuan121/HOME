package com.bjtu.redis;

import org.json.JSONObject;

import java.io.*;

public class JsonUtil {
    //读取json文件
    public static String readJsonFile(String fileName) {
        String jsonStr = "";
        try {
            File jsonFile = new File(fileName);
            FileReader fileReader = new FileReader(jsonFile);
            Reader reader = new InputStreamReader(new FileInputStream(jsonFile),"utf-8");
            int ch = 0;
            StringBuilder sb = new StringBuilder();
            while ((ch = reader.read()) != -1) {
                sb.append((char) ch);
            }
            fileReader.close();
            reader.close();
            jsonStr = sb.toString();
            return jsonStr;
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
    }
    public static int writeJsonFile(JSONObject json,String fileName){//将JS
        String j = json.toString();// ON对象转化为字符串
        try{
            PrintWriter writer = new PrintWriter(new BufferedWriter(new FileWriter(new File(fileName))));
            writer.write(j);
            writer.close();
        }catch(IOException ex){
            ex.printStackTrace();
        }
        return 0;
    }
}
