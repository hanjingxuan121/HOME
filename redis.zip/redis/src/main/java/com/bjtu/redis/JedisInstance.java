package com.bjtu.redis;

import redis.clients.jedis.Jedis;
import redis.clients.jedis.JedisPool;
import redis.clients.jedis.JedisPoolConfig;

public class JedisInstance {
    private JedisInstance(){ }
    public static enum SingletonEnum{
        INSTANCE;
        private JedisPool jedisPool;
        private SingletonEnum(){
            JedisPoolConfig config = new JedisPoolConfig();
            config.setMaxTotal(30);
            config.setMaxIdle(10);
            jedisPool = new JedisPool(config, "127.0.0.1", 6379);
        }
        public JedisPool getInstnce(){
            return jedisPool;
        }
    }
    public static JedisPool getInstance(){
        return SingletonEnum.INSTANCE.getInstnce();
    }
}

