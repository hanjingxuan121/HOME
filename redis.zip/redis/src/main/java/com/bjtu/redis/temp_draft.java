package com.bjtu.redis;

import java.text.SimpleDateFormat;
import java.util.Date;

public class temp_draft {
    public static void main(String[] args) {
        Date date=new Date();
        SimpleDateFormat dateFormat=new SimpleDateFormat("MM-dd");
        System.out.println(dateFormat.format(date));
    }
}
