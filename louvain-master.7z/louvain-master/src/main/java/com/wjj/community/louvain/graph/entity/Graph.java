package com.wjj.community.louvain.graph.entity;

import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.atomic.AtomicInteger;


public class Graph {


    private InverseAdjacencyList inverseAdjacencyList;


    private AdjacencyList adjacencyList;


    private HashSet<Integer> nodeIds;


    public Graph() {
        init();
    }


    public Graph(Collection<Link> links) {
        init(links);
    }

    private void init() {
        nodeIds = new HashSet<>();
        adjacencyList = new AdjacencyList();
        inverseAdjacencyList = new InverseAdjacencyList();
    }

    private void extendAdjacencyList(int index) {
        int currentIndex = adjacencyList.size() - 1;
        while (currentIndex++ < index) {
            adjacencyList.add(null);
        }
    }

    private void extendInverseAdjacencyList(int index) {
        int currentIndex = inverseAdjacencyList.size() - 1;
        while (currentIndex++ < index) {
            inverseAdjacencyList.add(null);
        }
    }

    private void init(Collection<Link> links) {
        init();
        addLinks(links);
    }


    public void addLinks(Collection<Link> links) {
        AtomicInteger max = new AtomicInteger(-1);
        links.forEach(link -> {
            int src = link.src;
            int dst = link.dst;
            nodeIds.add(src);
            nodeIds.add(dst);
            int cMax = Integer.max(src, dst);
            if (cMax > max.get()) {
                max.set(cMax);
            }
            extendAdjacencyList(src);
            extendAdjacencyList(dst);
            extendInverseAdjacencyList(dst);
            extendInverseAdjacencyList(src);
            Link newLink = link.clone();
            adjacencyList.addLink(newLink);
            inverseAdjacencyList.addLink(newLink);
        });
        if (max.get() > -1) {
            for (int i = 0; i <= max.get(); i++) {
                nodeIds.add(i);
            }
        }
    }


    public void addAcNodes(Collection<Integer> ids) {
        nodeIds.addAll(ids);
        AtomicInteger max = new AtomicInteger(0);
        ids.forEach(id -> {
            if (id > max.get()) {
                max.set(id);
            }
        });
        extendAdjacencyList(max.get());
        extendInverseAdjacencyList(max.get());
    }


    public Set<Integer> getNodes() {
        return (HashSet<Integer>) nodeIds.clone();
    }


    public Set<Link> getOutLinks(int id) {
        List<Link> qLinks = adjacencyList.get(id);
        Set<Link> links = new HashSet<>();
        if (qLinks != null) {
            links.addAll(qLinks);
        }
        return links;
    }


    public Set<Link> getInLinks(int id) {
        List<Link> qLinks = inverseAdjacencyList.get(id);
        Set<Link> links = new HashSet<>();
        if (qLinks != null) {
            links.addAll(qLinks);
        }
        return links;
    }


    public Set<Link> getBothWayLinks(int id) {
        Set<Link> links = getInLinks(id);
        links.addAll(getOutLinks(id));
        return links;
    }

    public Set<Integer> getOutNodes(int id) {
        Set<Integer> outNodes = new HashSet<>();
        getOutLinks(id).stream().map(link -> link.dst).forEach(outNodes::add);
        return outNodes;
    }

    public Set<Integer> getInNodes(int id) {
        Set<Integer> inNodes = new HashSet<>();
        getInLinks(id).stream().map(link -> link.src).forEach(inNodes::add);
        return inNodes;
    }

    public Set<Integer> getBothNodes(int id) {
        Set<Integer> bothNodes = getInNodes(id);
        bothNodes.addAll(getOutNodes(id));
        return bothNodes;
    }


    public double getOutWeight(int id) {
        double sum = 0.0;
        for (Link link : getOutLinks(id)) {
            sum += link.weight;
        }
        return sum;
    }


    public double getInWeight(int id) {
        double sum = 0.0;
        for (Link link : getInLinks(id)) {
            sum += link.weight;
        }
        return sum;
    }

    public double getBothWeight(int id) {
        return getInWeight(id) + getOutWeight(id);
    }

    public double totalWeight() {
        double w = 0.0;
        for (List<Link> links : adjacencyList) {
            if (links != null) {
                for (Link link : links) {
                    w += link.weight;
                }
            }
        }
        return w;
    }


    public int nodesNum() {
        return nodeIds.size();
    }


    public Set<Link> getLinksBetweenTwoNodes(int id1, int id2) {
        Set<Link> links = new HashSet<>();
        getOutLinks(id1).forEach(link -> {
            if (link.dst == id2) {
                links.add(link);
            }
        });
        getInLinks(id1).forEach(link -> {
            if (link.src == id2) {
                links.add(link);
            }
        });
        return links;
    }


    public Link getLinkFromOneToAnother(int id1, int id2) {
        Link resultLink = null;
        for (Link link : getOutLinks(id1)) {
            if (link.dst == id2) {
                resultLink = link;
                break;
            }
        }
        return resultLink;
    }


    public List<Link> getAdjacencyList() {
        return (List<Link>) adjacencyList.clone();
    }

}
