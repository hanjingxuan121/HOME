package com.wjj.community.louvain.graph.algo;

import java.util.Arrays;


public class CommunityInfo {

    public int communitiesNo;

 
    public int[] nodeCommunityNo;

    public int[][] communityNodeIds;

    @Override
    public String toString() {
        return "CommunityInfo{" +
                "communitiesNo=" + communitiesNo +
                ", nodeCommunityNo=" + Arrays.toString(nodeCommunityNo) +
                ", communityNodeIds=" + Arrays.deepToString(communityNodeIds) +
                '}';
    }

}
