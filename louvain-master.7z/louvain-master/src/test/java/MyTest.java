import com.wjj.community.louvain.graph.algo.CommunityInfo;
import com.wjj.community.louvain.graph.algo.LouvainCalculator;
import com.wjj.community.louvain.graph.entity.Graph;
import com.wjj.community.louvain.graph.entity.Link;
import org.junit.Test;

import java.util.Arrays;

public class MyTest {


    @Test
    public void testSingle() {
        Graph g = new Graph();
        // 0->1->2->0
        g.addLinks(Arrays.asList(new Link(0, 1, 1.0)));
        g.addLinks(Arrays.asList(new Link(1, 2, 1.0)));
        g.addLinks(Arrays.asList(new Link(2, 0, 1.0)));
        // 3->4->5->3
        g.addLinks(Arrays.asList(new Link(3, 4, 1.0)));
        g.addLinks(Arrays.asList(new Link(4, 5, 1.0)));
        g.addLinks(Arrays.asList(new Link(5, 3, 1.0)));

        LouvainCalculator louvainCalculator = new LouvainCalculator(g);

        CommunityInfo communityInfo = louvainCalculator.findCommunitiesSingleLevel();

        System.out.println(communityInfo);
    }


    @Test
    public void testMultiple() {
        Graph g = new Graph();
        // 0->1->2->0
        g.addLinks(Arrays.asList(new Link(0, 1, 1.0)));
        g.addLinks(Arrays.asList(new Link(1, 2, 1.0)));
        g.addLinks(Arrays.asList(new Link(2, 0, 1.0)));
        // 3->4->5->3
        g.addLinks(Arrays.asList(new Link(3, 4, 1.0)));
        g.addLinks(Arrays.asList(new Link(4, 5, 1.0)));
        g.addLinks(Arrays.asList(new Link(5, 3, 1.0)));
        // 6->7->8->6->5
        g.addLinks(Arrays.asList(new Link(6, 7, 1.0)));
        g.addLinks(Arrays.asList(new Link(7, 8, 1.0)));
        g.addLinks(Arrays.asList(new Link(8, 9, 1.0)));
        g.addLinks(Arrays.asList(new Link(9, 6, 1.0)));
        g.addLinks(Arrays.asList(new Link(6, 8, 1.0)));
        g.addLinks(Arrays.asList(new Link(7, 9, 1.0)));
        g.addLinks(Arrays.asList(new Link(6, 5, 1.0)));

        LouvainCalculator louvainCalculator = new LouvainCalculator(g);

        CommunityInfo communityInfo = louvainCalculator.findCommunitiesMultiLevel(2);

        System.out.println(communityInfo);
    }

}
